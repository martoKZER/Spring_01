package org.iesch.ad.demo.persintencia;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PersistenciaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PersistenciaApplication.class, args);
	}

}
