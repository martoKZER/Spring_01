package org.iesch.ad.demo.persintencia;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersistenciaApplicationTests {

	@Test
	void contextLoads() {
	}

}
